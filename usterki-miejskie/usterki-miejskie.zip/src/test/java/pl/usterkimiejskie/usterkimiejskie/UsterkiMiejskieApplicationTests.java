package pl.usterkimiejskie.usterkimiejskie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsterkiMiejskieApplicationTests {

    @Test
    void contextLoads() {
    }

}
