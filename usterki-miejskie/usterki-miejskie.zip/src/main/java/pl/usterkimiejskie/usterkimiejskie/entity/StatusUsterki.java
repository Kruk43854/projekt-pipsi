package pl.usterkimiejskie.usterkimiejskie.entity;

public enum StatusUsterki {
    ZGLOSZONA,
    POTWIERDZONA,
    W_TRAKCIE_NAPRAWY,
    NAPRAWIONA,
    ODRZUCONA
}